<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Mailer
    |--------------------------------------------------------------------------
    |
    | This option controls the default mailer that is used to send all email
    | messages unless another mailer is explicitly specified when sending
    | the message. All additional mailers can be configured within the
    | "mailers" array. Examples of each type of mailer are provided.
    |
    */

    'default' => env('MAIL_MAILER', 'log'),

    /*
    |--------------------------------------------------------------------------
    | Support Email
    |--------------------------------------------------------------------------
    |
    | This is the email address where contact form submissions will be sent.
    | ContactController sử dụng email này để gửi contact form emails.
    |
    | You can override this by setting SUPPORT_EMAIL in your .env file:
    | SUPPORT_EMAIL=support@yourdomain.com
    |
    | Priority: config('mail.support_email') > env('SUPPORT_EMAIL') > default
    |
    */

    'support_email' => env('SUPPORT_EMAIL', 'support@quickpoll.com'),

    /*
    |--------------------------------------------------------------------------
    | Mailer Configurations
    |--------------------------------------------------------------------------
    |
    | Here you may configure all of the mailers used by your application plus
    | their respective settings. Several examples have been configured for
    | you and you are free to add your own as your application requires.
    |
    | Laravel supports a variety of mail "transport" drivers that can be used
    | when delivering an email. You may specify which one you're using for
    | your mailers below. You may also add additional mailers if needed.
    |
    | Supported: "smtp", "sendmail", "mailgun", "ses", "ses-v2",
    |            "postmark", "resend", "log", "array",
    |            "failover", "roundrobin"
    |
    */

    'mailers' => [

        /**
         * SMTP Mailer Configuration
         * 
         * Dùng cho:
         * - Development: Mailpit (localhost:8025, port 1025)
         * - Production: Gmail, Outlook, hoặc SMTP server khác
         * 
         * .env configuration examples:
         * 
         * Mailpit (local development):
         * MAIL_MAILER=smtp
         * MAIL_HOST=127.0.0.1
         * MAIL_PORT=1025
         * MAIL_ENCRYPTION=null
         * 
         * Gmail (production):
         * MAIL_MAILER=smtp
         * MAIL_HOST=smtp.gmail.com
         * MAIL_PORT=587
         * MAIL_ENCRYPTION=tls
         * MAIL_USERNAME=your-email@gmail.com
         * MAIL_PASSWORD=your-16-char-app-password
         * 
         * Note: Gmail requires App Password, không dùng password thường
         */
        'smtp' => [
            'transport' => 'smtp',
            'host' => env('MAIL_HOST', '127.0.0.1'),
            'port' => env('MAIL_PORT', 2525),
            'encryption' => env('MAIL_ENCRYPTION', 'tls'), // tls, ssl, hoặc null
            'username' => env('MAIL_USERNAME'),
            'password' => env('MAIL_PASSWORD'), // Nên dùng quotes nếu có spaces: "xxxx xxxx xxxx xxxx"
            'timeout' => 10, // Giảm timeout xuống 10 giây để fail fast nếu bị block
            'stream' => [
                'ssl' => [
                    'allow_self_signed' => false,
                    'verify_peer' => true,
                    'verify_peer_name' => true,
                ],
            ],
            'local_domain' => env('MAIL_EHLO_DOMAIN', parse_url((string) env('APP_URL', 'http://localhost'), PHP_URL_HOST)),
        ],

        'ses' => [
            'transport' => 'ses',
        ],

        'postmark' => [
            'transport' => 'postmark',
            // 'message_stream_id' => env('POSTMARK_MESSAGE_STREAM_ID'),
            // 'client' => [
            //     'timeout' => 5,
            // ],
        ],

        'resend' => [
            'transport' => 'resend',
        ],

        'sendmail' => [
            'transport' => 'sendmail',
            'path' => env('MAIL_SENDMAIL_PATH', '/usr/sbin/sendmail -bs -i'),
        ],

        'log' => [
            'transport' => 'log',
            'channel' => env('MAIL_LOG_CHANNEL'),
        ],

        'array' => [
            'transport' => 'array',
        ],

        'failover' => [
            'transport' => 'failover',
            'mailers' => [
                'smtp',
                'log',
            ],
            'retry_after' => 60,
        ],

        'roundrobin' => [
            'transport' => 'roundrobin',
            'mailers' => [
                'ses',
                'postmark',
            ],
            'retry_after' => 60,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Global "From" Address
    |--------------------------------------------------------------------------
    |
    | You may wish for all emails sent by your application to be sent from
    | the same address. Here you may specify a name and address that is
    | used globally for all emails that are sent by your application.
    |
    */

    'from' => [
        'address' => env('MAIL_FROM_ADDRESS', 'hello@example.com'),
        'name' => env('MAIL_FROM_NAME', 'Example'),
    ],

];
