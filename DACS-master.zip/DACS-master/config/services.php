<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'resend' => [
        'key' => env('RESEND_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'google' => [
        'client_id' => env('GOOGLE_CLIENT_ID'),
        'client_secret' => env('GOOGLE_CLIENT_SECRET'),
        // Redirect URI: Ưu tiên GOOGLE_REDIRECT_URI (Render), fallback về GOOGLE_REDIRECT
        // Nếu không có env variable: dùng production URL (vì Render sẽ set APP_ENV=production)
        // Local development nên set GOOGLE_REDIRECT_URI trong .env
        'redirect' => env('GOOGLE_REDIRECT_URI', env('GOOGLE_REDIRECT', 'https://dacs-web.onrender.com/auth/google/callback')),
        'disable_ssl_verify' => env('GOOGLE_DISABLE_SSL_VERIFY', false),
    ],

];
